package com.Mohit.demo;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Path;


@RestController
public class Helloworld {

    @GetMapping(value ="/home")
    public String helloworld(){

        return "Hey this is me Mohit";
    }
}
